// ____________________________________________________________________________________________________________________________________________________________________________________________ //

import db from "../config.js";                                       // (pake koneksi MuSQL yang uda ada)


              // [GET semua SISWA -getSiswa]

export const getSiswa = (req, res) => {
    const sql = "SELECT * FROM siswa";                               // (query buat mengambil semua baris)
    db.query(sql, (err, result) => {                                // (jalanin query nya, result tu buat objek array)
        if (err) return res.status(500).json(err);                  // (ni kalo error bakal balikin status 500 intern sevrer error + tulisan error)
        res.json(result);                                           // (kalo ini buat sukses http 200)
    });
};


          // [GET SISWA by KODE -getSiswaByKode]

export const getSiswaByKode = (req, res) => {
    const sql = "SELECT * FROM siswa WHERE kode_siswa=?";             // (WHERE kode_siswa -itu query parameter)
    db.query(sql, [req.params.kode_siswa], (err, result) => {        // (req.params.k_s itu ambil drai /siswa/:kode_siswa)
        if (err) return res.status(500).json(err);                  
        res.json(result[0]);                                        // (ini  res.json buat balikin objek pertama, kalo gk nemu nnt 404)
    });
};


                    // [INSERT -insertSiswa]

            export const insertSiswa = (req, res) => {
    const {  nama_siswa, alamat_siswa, tgl_siswa, jurusan_siswa } = req.body;                                          // (const {kode_siswa, nama, ....} bdoy JSON)
    const sql = `INSERT INTO siswa ( nama_siswa, alamat_siswa, tgl_siswa, jurusan_siswa) VALUES (?, ?, ?, ?, ?)`;       // (query pake placehold (?) trs value array (k_s, nama, ...))
    db.query(sql, [ nama_siswa, alamat_siswa, tgl_siswa, jurusan_siswa], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: "📚 - book already added ✔️" });                                                     // (kalo sukses kiirm pesan suskses)
    });
};


                    // [UPDATE -updateSiswa]

export const updateSiswa = (req, res) => {
    const { nama_siswa, alamat_siswa, tgl_siswa, jurusan_siswa } = req.body;         // (ambil body yg diizinkan (judul, pengarang, ....) trs jalanin update)
    const sql = `
        UPDATE siswa
        SET nama_siswa=?, alamat_siswa=?, tgl_siswa=?, jurusan_siswa=?
        WHERE kode_siswa=?
    `;
                                                                    // (parameter akhir req.params buat identifier)

    db.query(sql, [nama_siswa, alamat_siswa, tgl_siswa, jurusan_siswa, req.params.kode_siswa], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: "📖 - book data already updated ✔️" });
    });
};


                    // [DELETE -deleteSiswa]

export const deleteSiswa = (req, res) => {
    const sql = "DELETE FROM siswa WHERE kode_siswa=?";
    db.query(sql, [req.params.kode_siswa], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: "Data siswa berhasil dihapus" });
    });
};

// ____________________________________________________________________________________________________________________________________________________________________________________________ //
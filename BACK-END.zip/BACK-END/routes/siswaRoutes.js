

// ________________________________________________________________________________________________________________ //

import express from "express";                      // (express router pake buat ngelompokin route source siswa)


    // [route di petain ke fungsi di kontroller]

import {
    getSiswa,                                        // GET
    getSiswaByKode,                                  // GET
    insertSiswa,                                     // POST
    updateSiswa,                                     // PUT
    deleteSiswa                                      // DELETE

} from "../controllers/siswaController.js";



const router = express.Router();

router.get("/", getSiswa);
router.get("/:kode_siswa", getSiswaByKode);
router.post("/", insertSiswa);
router.put("/:kode_siswa", updateSiswa);
router.delete("/:kode_siswa", deleteSiswa);


export default router;

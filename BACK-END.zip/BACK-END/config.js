// _____________________________________________________________________________________________________ //

import mysql from "mysql2"              // (cmengambil library dari MySQL2)


const db = mysql.createConnection({     // [buat koneksi ke server MySQL WorkBench]
    host: "localhost",
    user: "root",
    password: "Okkotsu#354",
    database: "db_siswaujk"
});


 db.connect((err) => {                  // (tes koneksi ke mysql workbench nya)
    if (err) {
        console.log("connection failed ❌:", err);
        return;
    }
        console.log("connection connected to workbench ✔️");
 });

 export default db;                     // (mengexpor koneksi agar file lain bisa pake koneksi yg smaa)

 // _____________________________________________________________________________________________________ //
import { Routes, Route } from "react-router-dom";
import Beranda from "../pages/Beranda";
import DaftarSiswa from "../pages/DaftarSiswa";

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Beranda />} />
      <Route path="/Daftar-Siswa" element={<DaftarSiswa />} />

    </Routes>
  );
}

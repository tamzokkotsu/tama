import sekolahImage from "../assets/Sekolah.jpg";

export default function Beranda() {
  return (
    <div className="container mt-4 text-center">
      <h1 className="text-center mb-4" style={{ fontFamily: 'verdana'}}><b>WELCOME TO SHIBUYA SCHOOL</b></h1>

    <img 
        src={sekolahImage} 
        alt="Foto Sekolah" 
        width="700"
        className="img-fluid rounded mb-4"
    />

      <p className="fs-6" style={{fontFamily: 'arial'}}>
        Shibuya Boarding School adalah institusi fiksi bernama Shibuya Metropolitan Curse Technical College (Sekolah Tinggi Teknik Kutukan Metropolitan Shibuya) dan sekolah saudaranya di Kyoto. Di sini, para siswa dilatih untuk menjadi penyihir jujutsu yang bertarung melawan roh terkutuk menggunakan energi kutukan. Sekolah ini adalah elemen penting dalam alur cerita dan bukan tempat nyata di dunia kita.
      </p>
    </div>
  );
}
